<?php

namespace Ajeya\Drive;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Drive\Skeleton\SkeletonClass
 */
class DriveFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'drive';
    }
}
