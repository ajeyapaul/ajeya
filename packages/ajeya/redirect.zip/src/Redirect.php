<?php

namespace Ajeya\Redirect;

class Redirect
{
    // Build your next great package.
}
