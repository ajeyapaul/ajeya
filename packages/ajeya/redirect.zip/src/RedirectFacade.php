<?php

namespace Ajeya\Redirect;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Redirect\Skeleton\SkeletonClass
 */
class RedirectFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'redirect';
    }
}
