<?php

namespace Ajeya\Dashboard;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Dashboard\Skeleton\SkeletonClass
 */
class DashboardFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'dashboard';
    }
}
