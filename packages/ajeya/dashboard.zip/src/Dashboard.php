<?php

namespace Ajeya\Dashboard;

class Dashboard
{
    // Build your next great package.
}
