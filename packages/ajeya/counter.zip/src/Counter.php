<?php

namespace Ajeya\Counter;

class Counter
{
    // Build your next great package.
}
