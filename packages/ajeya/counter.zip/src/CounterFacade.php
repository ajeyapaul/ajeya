<?php

namespace Ajeya\Counter;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Counter\Skeleton\SkeletonClass
 */
class CounterFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'counter';
    }
}
