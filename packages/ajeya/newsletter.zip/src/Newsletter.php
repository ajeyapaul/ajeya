<?php

namespace Ajeya\Newsletter;

class Newsletter
{
    // Build your next great package.
}
