<?php

namespace Ajeya\Messenger;

class Messenger
{
    // Build your next great package.
}
