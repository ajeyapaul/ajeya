<?php

namespace Ajeya\Clients;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Clients\Skeleton\SkeletonClass
 */
class ClientsFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'clients';
    }
}
