<?php

namespace Ajeya\Categories;

class Categories
{
    // Build your next great package.
}
