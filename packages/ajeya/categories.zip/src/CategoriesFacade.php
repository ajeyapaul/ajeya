<?php

namespace Ajeya\Categories;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Categories\Skeleton\SkeletonClass
 */
class CategoriesFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'categories';
    }
}
