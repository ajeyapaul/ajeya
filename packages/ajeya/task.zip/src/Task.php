<?php

namespace Ajeya\Task;

class Task
{
    // Build your next great package.
}
