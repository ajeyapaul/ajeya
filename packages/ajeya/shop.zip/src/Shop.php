<?php

namespace Ajeya\Shop;

class Shop
{
    // Build your next great package.
}
