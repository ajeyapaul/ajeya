<?php

namespace Ajeya\Shop;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Shop\Skeleton\SkeletonClass
 */
class ShopFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'shop';
    }
}
