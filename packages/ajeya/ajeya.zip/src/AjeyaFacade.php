<?php

namespace Ajeya\Ajeya;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Ajeya\Skeleton\SkeletonClass
 */
class AjeyaFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'ajeya';
    }
}
