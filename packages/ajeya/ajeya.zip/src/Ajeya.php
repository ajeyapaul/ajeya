<?php

namespace Ajeya\Ajeya;

class Ajeya
{
    // Build your next great package.
}
