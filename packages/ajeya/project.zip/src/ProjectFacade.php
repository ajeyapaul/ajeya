<?php

namespace Ajeya\Project;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Project\Skeleton\SkeletonClass
 */
class ProjectFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'project';
    }
}
