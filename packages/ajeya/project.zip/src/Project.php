<?php

namespace Ajeya\Project;

class Project
{
    // Build your next great package.
}
