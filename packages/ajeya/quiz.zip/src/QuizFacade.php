<?php

namespace Ajeya\Quiz;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Quiz\Skeleton\SkeletonClass
 */
class QuizFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'quiz';
    }
}
