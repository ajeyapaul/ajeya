<?php

namespace Ajeya\Quiz;

class Quiz
{
    // Build your next great package.
}
