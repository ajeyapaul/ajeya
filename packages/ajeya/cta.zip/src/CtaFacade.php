<?php

namespace Ajeya\Cta;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Cta\Skeleton\SkeletonClass
 */
class CtaFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'cta';
    }
}
