<?php

namespace Ajeya\Cta;

class Cta
{
    // Build your next great package.
}
