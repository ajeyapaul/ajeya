<?php

namespace Ajeya\Faq;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Faq\Skeleton\SkeletonClass
 */
class FaqFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'faq';
    }
}
