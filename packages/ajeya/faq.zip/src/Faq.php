<?php

namespace Ajeya\Faq;

class Faq
{
    // Build your next great package.
}
