<?php

namespace Ajeya\Blog;

class Blog
{
    // Build your next great package.
}
