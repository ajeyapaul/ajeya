<?php

namespace Ajeya\Twofactor;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Twofactor\Skeleton\SkeletonClass
 */
class TwofactorFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'twofactor';
    }
}
