<?php

namespace Ajeya\Twofactor;

class Twofactor
{
    // Build your next great package.
}
