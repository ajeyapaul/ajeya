<?php

namespace Ajeya\User;

class User
{
    // Build your next great package.
}
