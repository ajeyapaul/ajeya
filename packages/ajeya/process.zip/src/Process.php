<?php

namespace Ajeya\Process;

class Process
{
    // Build your next great package.
}
