<?php

namespace Ajeya\Organization;

class Organization
{
    // Build your next great package.
}
