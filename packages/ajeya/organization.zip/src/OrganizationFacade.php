<?php

namespace Ajeya\Organization;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Organization\Skeleton\SkeletonClass
 */
class OrganizationFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'organization';
    }
}
