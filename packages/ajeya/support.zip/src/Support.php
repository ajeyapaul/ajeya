<?php

namespace Ajeya\Support;

class Support
{
    // Build your next great package.
}
