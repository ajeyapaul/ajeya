<?php

namespace Ajeya\Support;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Support\Skeleton\SkeletonClass
 */
class SupportFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'support';
    }
}
