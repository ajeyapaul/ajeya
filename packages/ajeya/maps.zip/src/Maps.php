<?php

namespace Ajeya\Maps;

class Maps
{
    // Build your next great package.
}
