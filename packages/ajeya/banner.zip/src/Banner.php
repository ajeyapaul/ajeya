<?php

namespace Ajeya\Banner;

class Banner
{
    // Build your next great package.
}
