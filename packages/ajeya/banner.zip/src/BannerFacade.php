<?php

namespace Ajeya\Banner;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Banner\Skeleton\SkeletonClass
 */
class BannerFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'banner';
    }
}
