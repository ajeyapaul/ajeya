<?php

namespace Ajeya\Media;

class Media
{
    // Build your next great package.
}
