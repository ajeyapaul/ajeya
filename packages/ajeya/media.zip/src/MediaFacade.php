<?php

namespace Ajeya\Media;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Media\Skeleton\SkeletonClass
 */
class MediaFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'media';
    }
}
