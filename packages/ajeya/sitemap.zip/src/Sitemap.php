<?php

namespace Ajeya\Sitemap;

class Sitemap
{
    // Build your next great package.
}
