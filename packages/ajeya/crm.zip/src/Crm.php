<?php

namespace Ajeya\Crm;

class Crm
{
    // Build your next great package.
}
