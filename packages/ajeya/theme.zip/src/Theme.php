<?php

namespace Ajeya\Theme;

class Theme
{
    // Build your next great package.
}
