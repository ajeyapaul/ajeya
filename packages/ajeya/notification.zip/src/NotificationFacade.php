<?php

namespace Ajeya\Notification;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Notification\Skeleton\SkeletonClass
 */
class NotificationFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'notification';
    }
}
