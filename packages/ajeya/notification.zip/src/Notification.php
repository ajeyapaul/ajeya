<?php

namespace Ajeya\Notification;

class Notification
{
    // Build your next great package.
}
