<?php

namespace Ajeya\Schedule;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Schedule\Skeleton\SkeletonClass
 */
class ScheduleFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'schedule';
    }
}
