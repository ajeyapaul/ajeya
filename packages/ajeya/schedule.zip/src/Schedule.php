<?php

namespace Ajeya\Schedule;

class Schedule
{
    // Build your next great package.
}
