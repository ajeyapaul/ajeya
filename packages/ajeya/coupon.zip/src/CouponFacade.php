<?php

namespace Ajeya\Coupon;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Coupon\Skeleton\SkeletonClass
 */
class CouponFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'coupon';
    }
}
