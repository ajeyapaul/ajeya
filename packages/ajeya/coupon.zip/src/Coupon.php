<?php

namespace Ajeya\Coupon;

class Coupon
{
    // Build your next great package.
}
