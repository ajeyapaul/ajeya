<?php

namespace Ajeya\Page;

class Page
{
    // Build your next great package.
}
