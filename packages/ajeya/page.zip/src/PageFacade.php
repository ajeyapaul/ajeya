<?php

namespace Ajeya\Page;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Page\Skeleton\SkeletonClass
 */
class PageFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'page';
    }
}
