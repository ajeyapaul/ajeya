<?php

namespace Ajeya\Forum;

class Forum
{
    // Build your next great package.
}
