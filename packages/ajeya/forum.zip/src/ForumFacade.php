<?php

namespace Ajeya\Forum;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Forum\Skeleton\SkeletonClass
 */
class ForumFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'forum';
    }
}
