<?php

namespace Ajeya\Webform;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Webform\Skeleton\SkeletonClass
 */
class WebformFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'webform';
    }
}
