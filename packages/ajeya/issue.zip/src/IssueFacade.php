<?php

namespace Ajeya\Issue;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Issue\Skeleton\SkeletonClass
 */
class IssueFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'issue';
    }
}
