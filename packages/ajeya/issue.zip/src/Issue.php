<?php

namespace Ajeya\Issue;

class Issue
{
    // Build your next great package.
}
