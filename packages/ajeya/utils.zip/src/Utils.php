<?php

namespace Ajeya\Utils;

class Utils
{
    // Build your next great package.
}
