<?php

namespace Ajeya\Utils;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Utils\Skeleton\SkeletonClass
 */
class UtilsFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'utils';
    }
}
