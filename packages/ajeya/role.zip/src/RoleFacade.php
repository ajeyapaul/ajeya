<?php

namespace Ajeya\Role;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Role\Skeleton\SkeletonClass
 */
class RoleFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'role';
    }
}
