<?php

namespace Ajeya\Role;

class Role
{
    // Build your next great package.
}
