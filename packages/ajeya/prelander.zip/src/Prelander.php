<?php

namespace Ajeya\Prelander;

class Prelander
{
    // Build your next great package.
}
