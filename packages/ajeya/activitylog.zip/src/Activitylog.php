<?php

namespace Ajeya\Activitylog;

class Activitylog
{
    // Build your next great package.
}
