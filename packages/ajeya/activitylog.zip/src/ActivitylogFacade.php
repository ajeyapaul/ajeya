<?php

namespace Ajeya\Activitylog;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Activitylog\Skeleton\SkeletonClass
 */
class ActivitylogFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'activitylog';
    }
}
