<?php

namespace Ajeya\Wallet;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Wallet\Skeleton\SkeletonClass
 */
class WalletFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'wallet';
    }
}
