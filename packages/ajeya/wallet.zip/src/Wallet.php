<?php

namespace Ajeya\Wallet;

class Wallet
{
    // Build your next great package.
}
