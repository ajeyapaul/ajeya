<?php

namespace Ajeya\Contact;

class Contact
{
    // Build your next great package.
}
