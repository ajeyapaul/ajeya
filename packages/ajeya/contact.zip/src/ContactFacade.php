<?php

namespace Ajeya\Contact;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Contact\Skeleton\SkeletonClass
 */
class ContactFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'contact';
    }
}
