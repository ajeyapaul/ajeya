<?php

namespace Ajeya\Invoice;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Invoice\Skeleton\SkeletonClass
 */
class InvoiceFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'invoice';
    }
}
