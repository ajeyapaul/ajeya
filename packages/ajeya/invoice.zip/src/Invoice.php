<?php

namespace Ajeya\Invoice;

class Invoice
{
    // Build your next great package.
}
