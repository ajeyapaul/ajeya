<?php

namespace Ajeya\Expenses;

class Expenses
{
    // Build your next great package.
}
