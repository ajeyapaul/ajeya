<?php

namespace Ajeya\Seo;

class Seo
{
    // Build your next great package.
}
