<?php

namespace Ajeya\Affiliate;

class Affiliate
{
    // Build your next great package.
}
