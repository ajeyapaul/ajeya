<?php

namespace Ajeya\Affiliate;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Affiliate\Skeleton\SkeletonClass
 */
class AffiliateFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'affiliate';
    }
}
