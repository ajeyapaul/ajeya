<?php

namespace Ajeya\Slider;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Slider\Skeleton\SkeletonClass
 */
class SliderFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'slider';
    }
}
