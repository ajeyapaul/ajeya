<?php

namespace Ajeya\Slider;

class Slider
{
    // Build your next great package.
}
