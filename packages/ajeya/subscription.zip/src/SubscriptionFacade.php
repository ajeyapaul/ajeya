<?php

namespace Ajeya\Subscription;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Subscription\Skeleton\SkeletonClass
 */
class SubscriptionFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'subscription';
    }
}
