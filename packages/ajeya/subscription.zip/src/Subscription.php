<?php

namespace Ajeya\Subscription;

class Subscription
{
    // Build your next great package.
}
