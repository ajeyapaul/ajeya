<?php

namespace Ajeya\Gallery;

class Gallery
{
    // Build your next great package.
}
