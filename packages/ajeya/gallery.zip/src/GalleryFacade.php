<?php

namespace Ajeya\Gallery;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Gallery\Skeleton\SkeletonClass
 */
class GalleryFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'gallery';
    }
}
