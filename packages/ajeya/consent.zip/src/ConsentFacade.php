<?php

namespace Ajeya\Consent;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Consent\Skeleton\SkeletonClass
 */
class ConsentFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'consent';
    }
}
