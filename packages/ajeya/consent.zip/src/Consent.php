<?php

namespace Ajeya\Consent;

class Consent
{
    // Build your next great package.
}
