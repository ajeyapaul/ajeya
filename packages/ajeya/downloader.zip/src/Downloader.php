<?php

namespace Ajeya\Downloader;

class Downloader
{
    // Build your next great package.
}
