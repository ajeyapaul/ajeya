<?php

namespace Ajeya\Test;

class Test
{
    // Build your next great package.
}
