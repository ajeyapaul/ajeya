<?php

namespace Ajeya\Calendar;

class Calendar
{
    // Build your next great package.
}
