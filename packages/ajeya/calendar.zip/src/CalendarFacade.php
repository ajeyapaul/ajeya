<?php

namespace Ajeya\Calendar;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Calendar\Skeleton\SkeletonClass
 */
class CalendarFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'calendar';
    }
}
