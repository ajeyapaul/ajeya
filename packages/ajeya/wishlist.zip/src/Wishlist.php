<?php

namespace Ajeya\Wishlist;

class Wishlist
{
    // Build your next great package.
}
