<?php

namespace Ajeya\Hr;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Hr\Skeleton\SkeletonClass
 */
class HrFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'hr';
    }
}
