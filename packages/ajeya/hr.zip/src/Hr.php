<?php

namespace Ajeya\Hr;

class Hr
{
    // Build your next great package.
}
