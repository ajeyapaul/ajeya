<?php

namespace Ajeya\Share;

class Share
{
    // Build your next great package.
}
