<?php

namespace Ajeya\Share;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Share\Skeleton\SkeletonClass
 */
class ShareFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'share';
    }
}
