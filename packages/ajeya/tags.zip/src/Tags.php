<?php

namespace Ajeya\Tags;

class Tags
{
    // Build your next great package.
}
