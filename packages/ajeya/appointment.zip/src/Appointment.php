<?php

namespace Ajeya\Appointment;

class Appointment
{
    // Build your next great package.
}
