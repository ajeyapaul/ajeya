<?php

namespace Ajeya\Appointment;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Appointment\Skeleton\SkeletonClass
 */
class AppointmentFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'appointment';
    }
}
