<?php

namespace Ajeya\Auth;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Auth\Skeleton\SkeletonClass
 */
class AuthFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'auth';
    }
}
