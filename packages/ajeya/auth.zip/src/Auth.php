<?php

namespace Ajeya\Auth;

class Auth
{
    // Build your next great package.
}
