<?php

namespace Ajeya\Form;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Form\Skeleton\SkeletonClass
 */
class FormFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'form';
    }
}
