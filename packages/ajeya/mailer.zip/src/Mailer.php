<?php

namespace Ajeya\Mailer;

class Mailer
{
    // Build your next great package.
}
