<?php

namespace Ajeya\Mailer;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Mailer\Skeleton\SkeletonClass
 */
class MailerFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'mailer';
    }
}
