<?php

namespace Ajeya\Vault;

class Vault
{
    // Build your next great package.
}
