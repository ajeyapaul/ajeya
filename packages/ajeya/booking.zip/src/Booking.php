<?php

namespace Ajeya\Booking;

class Booking
{
    // Build your next great package.
}
