<?php

namespace Ajeya\Booking;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Booking\Skeleton\SkeletonClass
 */
class BookingFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'booking';
    }
}
