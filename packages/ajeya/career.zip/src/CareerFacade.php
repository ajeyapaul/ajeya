<?php

namespace Ajeya\Career;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Career\Skeleton\SkeletonClass
 */
class CareerFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'career';
    }
}
