<?php

namespace Ajeya\Career;

class Career
{
    // Build your next great package.
}
