<?php

namespace Ajeya\Impersonate;

class Impersonate
{
    // Build your next great package.
}
