<?php

namespace Ajeya\Counters;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Counters\Skeleton\SkeletonClass
 */
class CountersFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'counters';
    }
}
