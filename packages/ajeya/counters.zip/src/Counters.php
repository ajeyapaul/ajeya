<?php

namespace Ajeya\Counters;

class Counters
{
    // Build your next great package.
}
