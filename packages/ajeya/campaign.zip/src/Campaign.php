<?php

namespace Ajeya\Campaign;

class Campaign
{
    // Build your next great package.
}
