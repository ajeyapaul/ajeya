<?php

namespace Ajeya\Charts;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Ajeya\Charts\Skeleton\SkeletonClass
 */
class ChartsFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'charts';
    }
}
