<?php

namespace Ajeya\Charts;

class Charts
{
    // Build your next great package.
}
